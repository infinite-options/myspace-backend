"""Type definition backward compatibility."""
# flake8: noqa
from __future__ import annotations

from typing import Final, Literal, Protocol, SupportsIndex
